package com.sfaci.incidencias.util;

/**
 * Created by dam on 28/11/17.
 */

public class Constantes {

    public static String URL = "https://www.zaragoza.es/sede/servicio/via-publica/incidencia.json";
}
